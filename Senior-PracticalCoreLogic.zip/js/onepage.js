function setupOnePage() {
  sh_highlightDocument('/js/sh_lang/', '.min.js')
  
  centerSlides($("#slides > .slide"))
}